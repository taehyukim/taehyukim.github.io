package examples.boot.myshop.security;

import lombok.*;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class MemberInfo {
    private Integer id;
    private String email;
}
