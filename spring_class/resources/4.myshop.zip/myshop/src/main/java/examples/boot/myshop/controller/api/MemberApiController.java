package examples.boot.myshop.controller.api;

import examples.boot.myshop.security.MemberInfo;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/members")
public class MemberApiController {
    @GetMapping
    public String member(MemberInfo memberInfo) {
        System.out.println("members : " + memberInfo);
        return "member - id: " + memberInfo.getId() + ", email: " + memberInfo.getEmail();
    }
}
