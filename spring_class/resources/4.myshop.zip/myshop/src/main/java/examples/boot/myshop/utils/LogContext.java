package examples.boot.myshop.utils;

public class LogContext {
    public static ThreadLocal<Long> time = new ThreadLocal<Long>();
}
