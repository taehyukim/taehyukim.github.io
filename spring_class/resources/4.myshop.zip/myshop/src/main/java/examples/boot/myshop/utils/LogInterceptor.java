package examples.boot.myshop.utils;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;

public class LogInterceptor extends HandlerInterceptorAdapter {
    @Override
    // dispatcherServlet 이 controller 를 실행하기 전에 preHandle 을 호출
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        //request.setAttribute("st", System.currentTimeMillis());
        LogContext.time.set(System.nanoTime());
        System.out.println("preHandle :" + handler + " :: " + LogContext.time.get());
        return true; // true 를 반환해야 정상적으로 수행됐다고 판단하고 controller 작업 수행
    }

    @Override
    // dispatcherServlet 이 controller 를 실행하고 난 후에 postHandle 을 호출
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        long endTime = System.nanoTime();
        //long startTime = (long)request.getAttribute("st");
        long startTime = LogContext.time.get();

        System.out.println("postHandle :" + handler + " time: " + (endTime - startTime));
    }
}
