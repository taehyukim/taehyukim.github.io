package examples.boot.myshop.repository;

import examples.boot.myshop.domain.Member;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface MemberRepository extends JpaRepository<Member, Long> {
    public Long countByNameContains(String name);

    @Query("SELECT COUNT(m) FROM Member m WHERE m.name = :name")
    public Long countAllByName(@Param("name") String name);
}
