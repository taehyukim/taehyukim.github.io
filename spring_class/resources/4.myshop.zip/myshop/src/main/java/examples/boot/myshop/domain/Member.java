package examples.boot.myshop.domain;

import lombok.*;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "memeber")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Member implements Serializable {
    // 필드 선언
    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String email;
    private String password;
}
