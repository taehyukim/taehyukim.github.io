package examples.boot.myshop;

import examples.boot.myshop.domain.Member;
import examples.boot.myshop.repository.MemberRepository;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringRunner.class)
@SpringBootTest
@Transactional
public class MyshopApplicationTests {
	@Autowired
	MemberRepository memberRepository;

	@Test
	public void contextLoads() {
	}

	@Test
	public void testNotNull() {
		Assert.assertNotNull(memberRepository);
	}

	@Test
	public void testSaveMember() {
		System.out.println("------------------------");
		Member member = new Member();
		member.setId(2L);
		member.setName("Kim");
		member.setEmail("taehyukim@ebay.com");
		member.setPassword("1234");

		memberRepository.save(member);
		System.out.println(member.getId());

		Member member2 = memberRepository.getOne(member.getId());
		if (member == member2) {
			System.out.println("member == member2");
		} else {
			System.out.println("member != member2");
		}
		System.out.println("-------------------------");
	}
}
