package examples.boot.myshop.domain;

import lombok.*;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Member {
    // 필드 선언
    private Long id;
    private String name;
    private String email;
    private String password;
}
